# market data
order_books = {}
instruments = {}
tickers_container = []
mark_px_container = []

# pms
balance_and_position_container = []
account_container = []
positions_container = []

# oms
orders_container = []
